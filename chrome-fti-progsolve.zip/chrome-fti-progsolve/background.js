chrome.runtime.onMessage.addListener(
   async function (request, sender, sendResponse) {
      if (request.key == 'task') {
         let testData = await new Promise((resolve) => chrome.storage.local.get('test', function (res) {
            resolve(res);
         }));
         let roomData = await new Promise((resolve) => chrome.storage.local.get('room', function (res) {
            resolve(res);
         }));

         //alert(sender.tab.url + '\n' + request.task + request.answers);

         let task = request.task,
            answers = request.answers;

         console.log(request);

         const host = 'http://s9788911.beget.tech/pycpp/php/ext/';
         try {
            let answer = await fetch(host + 'get-answer.php', { // FIXME: exit before async ready
               method: 'POST',
               headers: {
                  'Content-Type': 'application/x-www-form-urlencoded',
               },
               body: Object.entries({
                  task: task,
                  answers: answers,
                  testId: testData.test.id,
                  roomId: roomData.room.id,
               }).map(([key, val]) => `${key}=${val}`).join('&'),
            }).then(r => r.text());

            sendResponse({ answer: answer });
         }
         catch (err) {
            console.error(err);
         }
      }

      return true; // FIXME: special to fix problem but no res
   });