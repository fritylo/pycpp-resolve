function main() {
   forwardTask();


   // STOP: MUTATION HANDLE
   // Select the node that will be observed for mutations
   const targetNode = document.body;

   // Options for the observer (which mutations to observe)
   const config = { attributes: true, childList: true, subtree: true };

   // Callback function to execute when mutations are observed
   const callback = function (mutationsList, observer) {
      forwardTask();
   };

   // Create an observer instance linked to the callback function
   const observer = new MutationObserver(callback);

   // Start observing the target node for configured mutations
   observer.observe(targetNode, config);

   // Later, you can stop observing
   //observer.disconnect();
}

function forwardTask() {
   const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

   let task = document.querySelector('.bbcode');
   if (!task) task = document.querySelector('.qpad');
   task = task.textContent;
   let answers = Array.from(document.querySelectorAll('.ans_content_prefixed'))
         .map((ans) => ans.textContent.trim())
         .sort()
         .map((ans, i) => letters[i] + ') ' + ans)
         .join('\n');

   console.log('task:', task);
   console.log('answers:', answers);

   chrome.runtime.sendMessage({ key: 'task', task: encodeURIComponent(task), answers: encodeURIComponent(answers) }, function (response) {
      console.log("Response: ", decodeURI(response.answer));
   });
}

main();