async function main() {
   const host = 'http://s9788911.beget.tech/pycpp/php/ext/';
   let status = '';

   async function checkConnection() {
      try {
         status = await fetch(host + 'check.php', {
            method: 'GET'
         }).then(r => {
            if (r.status.toString().match(/^4/)) 
               throw new Error('Неверное обращение ' + r.status + ` (${r.statusText})`);
            return r.text();
         });
      } catch (err) {
         status += '<br><span style="color: red">' + err + "</span>";
      }
   }

   await checkConnection();

   async function generateTestSelect() {
      try {
         let list = await fetch(host + 'test-list.php', {
            method: 'GET'
         }).then(r => {
            if (r.status.toString().match(/^4/))
               throw new Error(`Неверное обращение (тесты) ${r.status} (${r.statusText})`);
            return r.json();
         });

         let options = list.map(({id_test: id, test_name: name}) => {
            let option = document.createElement('option');
            option.value = id;
            option.textContent = name;
            return option;
         })
         
         selectTest.append(...options);
      } catch (err) {
         status += '<br><span style="color: red">' + err + "</span>";
      }
   }

   await generateTestSelect();

   async function generateRoomSelect() {
      try {
         let list = await fetch(host + 'room-list.php', {
            method: 'GET'
         }).then(r => {
            if (r.status.toString().match(/^4/))
               throw new Error(`Неверное обращение (комнаты) ${r.status} (${r.statusText})`);
            return r.json();
         });

         let options = list.map(({ id_room: id, room_name: name }) => {
            let option = document.createElement('option');
            option.value = id;
            option.textContent = name;
            return option;
         });

         selectRoom.append(...options);
      } catch (err) {
         status += '<br><span style="color: red">' + err + "</span>";
      }
   }

   await generateRoomSelect();

   selectTest.addEventListener('change', e => {
      let selected = e.target.options[e.target.selectedIndex];
      console.warn(selected);
      let [testName, testId] = [selected.textContent, selected.value];
      chrome.storage.local.set({ test: {name: testName, id: testId} }, function () {
         alert(`Тест изменён на: ${testName} [${testId}]`);
      });
   });

   selectRoom.addEventListener('change', e => {
      let selected = e.target.options[e.target.selectedIndex];
      console.warn(selected);
      let [roomName, roomId] = [selected.textContent, selected.value];
      chrome.storage.local.set({ room: { name: roomName, id: roomId } }, function () {
         alert(`Комната изменена на: ${roomName} [${roomId}]`);
      });
   });


   let testData = await new Promise((resolve) => chrome.storage.local.get('test', function (res) {
      resolve(res);
   }));
   if (testData)
      selectTest.selectedIndex = Array.from(selectTest.options).findIndex(opt => opt.textContent == testData.test.name);

   let roomData = await new Promise((resolve) => chrome.storage.local.get('room', function (res) {
      resolve(res);
   }));
   if (roomData)
      selectRoom.selectedIndex = Array.from(selectRoom.options).findIndex(opt => opt.textContent == roomData.room.name);

   connectionStatus.innerHTML = '<span style="color: green">' + status + '</span>';
}

main().then(() => {});